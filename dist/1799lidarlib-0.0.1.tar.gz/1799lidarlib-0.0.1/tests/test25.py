from lidarLib.lidarConfigTool import demoRun

demoRun("testFile.json")