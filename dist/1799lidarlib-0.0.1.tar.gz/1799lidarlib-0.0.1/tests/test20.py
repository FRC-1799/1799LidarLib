from lidarLib.FRCQuickstartLidarProject import FRCQuickstartLidarProject

FRCQuickstartLidarProject.fromConfigs("lidarProject.json")