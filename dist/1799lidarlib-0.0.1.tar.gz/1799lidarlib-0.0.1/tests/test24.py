import time
import pygame


pygame.init()
time.sleep(1)
pygame.quit()
time.sleep(1)
pygame.init()
time.sleep(1)