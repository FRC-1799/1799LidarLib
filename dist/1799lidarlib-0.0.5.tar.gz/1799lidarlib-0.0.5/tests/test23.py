from lidarLib.lidarConfigTool import lidarConfigurationTool

lidarConfigurationTool()