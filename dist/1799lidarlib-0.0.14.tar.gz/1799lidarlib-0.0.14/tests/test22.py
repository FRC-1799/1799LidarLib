val =input()
print(hex(int(val, 16)))