from lidarLib.lidarConfigTool import demoRun

demoRun("lidar0.json")